﻿public abstract class GameObject
{
    public string Symbol { get; set; }

    public string contractText;
    public string GetText { get => contractText; }
}

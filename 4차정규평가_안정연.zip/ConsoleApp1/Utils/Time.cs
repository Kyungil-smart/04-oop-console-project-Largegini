﻿using System.Diagnostics;

public class Time
{
    private Stopwatch _stopwatch;

    private double _currentTime;
    private double _prevTime;



}

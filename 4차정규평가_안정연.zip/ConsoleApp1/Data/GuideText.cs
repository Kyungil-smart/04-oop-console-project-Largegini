﻿using System;

public struct GuideText
{
    public string[] Text;
    public ConsoleColor Color;
   
    public GuideText(ConsoleColor color)
    {
        Text = new string[]
        {
            "    조작키 안내",
            "        위",
            "        ↑",
            "  ←     ↓     →",
            "왼 쪽 아 래 오른쪽",
            "Enter : 상호작용 / 선택 / 입력 완료",
            "Tab : 가방 열기",
            "ESC : 닫기",
            "열쇠를 찾아 문을 열고 탈출하자",
            "🔔 : 상호작용하여 문제를 풀고 열쇠를 얻자",
            "🔒 : 잠긴 문 🔓 : 열린 문",
            "문 위에서 인벤토리를 열고 열쇠를 사용하면 열 수 있다."

        };
        Color = color;
    }
}